<?php
/*!
* HybridAuth
* http://hybridauth.sourceforge.net | http://github.com/hybridauth/hybridauth
* (c) 2009-2012, HybridAuth authors | http://hybridauth.sourceforge.net/licenses.html
*/

// ----------------------------------------------------------------------------------------
//	HybridAuth Config file: http://hybridauth.sourceforge.net/userguide/Configuration.html
// ----------------------------------------------------------------------------------------
return
array (
  'base_url' => '',
  'providers' => 
  array (
    'OpenID' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Yahoo' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'AOL' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Google' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Facebook' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Twitter' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Live' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'MySpace' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'LinkedIn' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
    'Foursquare' => 
    array (
      'enabled' => false,
      'keys' => 
      array (
        'id' => '',
        'key' => '',
        'secret' => '',
      ),
    ),
  ),
  'debug_mode' => false,
  'debug_file' => '',
);
